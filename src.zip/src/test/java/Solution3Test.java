import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class Solution3Test {

    private final Solution3 solution = new Solution3();

    @Test
    public void testGivenCase1() {
        int[] A = {1, 1, 3};
        int[] B = {2, 2, 1};
        int S = 3;
        assertTrue(solution.solution(A, B, S));
    }

    @Test
    public void testGivenCase2() {
        int[] A = {3, 2, 3, 1};
        int[] B = {1, 3, 1, 2};
        int S = 3;
        assertFalse(solution.solution(A, B, S));
    }

    @Test
    public void testGivenCase3() {
        int[] A = {2, 5, 6, 5};
        int[] B = {5, 4, 2, 2};
        int S = 8;
        assertTrue(solution.solution(A, B, S));
    }

    @Test
    public void testGivenCase4() {
        int[] A = {1, 2, 1, 6, 8, 7, 8};
        int[] B = {2, 3, 4, 7, 7, 8, 7};
        int S = 10;
        assertFalse(solution.solution(A, B, S));
    }

    // Additional custom test cases

    // Case where there is only one patient and one slot
    @Test
    public void testOnePatientOneSlot() {
        int[] A = {1};
        int[] B = {2};
        int S = 2;
        assertTrue(solution.solution(A, B, S));
    }

    // Case where two patients want the same slot but no other alternatives
    @Test
    public void testConflictNoResolution() {
        int[] A = {1, 1};
        int[] B = {2, 2};
        int S = 2;
        assertFalse(solution.solution(A, B, S));
    }

    // Case where there are more patients than slots
    @Test
    public void testMorePatientsThanSlots() {
        int[] A = {1, 2, 3, 4};
        int[] B = {2, 3, 4, 1};
        int S = 3; // 4 patients, but only 3 slots available
        assertFalse(solution.solution(A, B, S));
    }

    // Case where all patients can be assigned due to non-overlapping preferences
    @Test
    public void testNoConflicts() {
        int[] A = {1, 2, 3, 4};
        int[] B = {5, 6, 7, 8};
        int S = 8;
        assertTrue(solution.solution(A, B, S));
    }

    // Case where every patient has exactly one unique slot to choose
    @Test
    public void testUniqueSlots() {
        int[] A = {1, 2, 3};
        int[] B = {4, 5, 6};
        int S = 6;
        assertTrue(solution.solution(A, B, S));
    }

    // Case where patients' preferences are cyclical but resolvable
    @Test
    public void testCyclicButResolvable() {
        int[] A = {1, 2, 3};
        int[] B = {2, 3, 1};
        int S = 3;
        assertTrue(solution.solution(A, B, S));
    }

    // Edge case with the minimum number of slots (S = 2) and exactly two patients
    @Test
    public void testMinimumSlotsTwoPatients() {
        int[] A = {1, 2};
        int[] B = {2, 1};
        int S = 2;
        assertTrue(solution.solution(A, B, S));
    }

    // Edge case where all patients prefer the same slot and there's no alternative
    @Test
    public void testAllPatientsSamePreference() {
        int[] A = {1, 1, 1};
        int[] B = {1, 1, 1};
        int S = 1;
        assertFalse(solution.solution(A, B, S));
    }

    // Case where each patient has one overlapping preference and some can be shifted
    @Test
    public void testOverlappingWithResolution() {
        int[] A = {1, 2, 3};
        int[] B = {2, 3, 4};
        int S = 4;
        assertTrue(solution.solution(A, B, S));
    }

    // Stress test with a large number of patients and slots
    @Test
    public void testLargeInput() {
        int N = 100000;
        int S = 100000;
        int[] A = new int[N];
        int[] B = new int[N];
        for (int i = 0; i < N; i++) {
            A[i] = (i % S) + 1;
            B[i] = ((i + 1) % S) + 1;
        }
        assertTrue(solution.solution(A, B, S));
    }
}

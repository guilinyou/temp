import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class Solution3Test {
    private Solution3 solution = new Solution3();
    @Test
    void testExample1() {
        int[] A = {1, 1, 3};
        int[] B = {2, 2, 1};
        int S = 3;
        assertTrue(solution.solution(A, B, S));
    }

    @Test
    void testExample2() {
        int[] A = {3, 2, 3, 1};
        int[] B = {1, 3, 1, 2};
        int S = 3;
        assertFalse(solution.solution(A, B, S));
    }

    @Test
    void testExample3() {
        int[] A = {2, 5, 6, 5};
        int[] B = {5, 4, 2, 2};
        int S = 8;
        assertTrue(solution.solution(A, B, S));
    }

    @Test
    void testExample4() {
        int[] A = {1, 2, 1, 6, 8, 7, 8};
        int[] B = {2, 3, 4, 7, 7, 8, 7};
        int S = 10;
        assertFalse(solution.solution(A, B, S));
    }

    @Test
    void testMinimumInput() {
        int[] A = {1};
        int[] B = {2};
        int S = 2;
        assertTrue(solution.solution(A, B, S));
    }

    @Test
    void testAllSamePreference() {
        int[] A = {1, 1, 1, 1};
        int[] B = {2, 2, 2, 2};
        int S = 2;
        assertFalse(solution.solution(A, B, S));
    }

    @Test
    void testLargeInput() {
        int N = 100000;
        int S = 200000;
        int[] A = new int[N];
        int[] B = new int[N];
        for (int i = 0; i < N; i++) {
            A[i] = i + 1;
            B[i] = S - i;
        }
        assertTrue(solution.solution(A, B, S));
    }

    @Test
    void testNoSolutionLargeInput() {
        int N = 100000;
        int S = 99999;
        int[] A = new int[N];
        int[] B = new int[N];
        for (int i = 0; i < N; i++) {
            A[i] = 1;
            B[i] = 2;
        }
        assertFalse(solution.solution(A, B, S));
    }
}

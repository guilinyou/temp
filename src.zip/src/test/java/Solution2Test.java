import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.Arrays;
import java.util.stream.Stream;

class Solution2Test {

    Solution2 solution = new Solution2();

    @ParameterizedTest
    @MethodSource("provideTestCases")
    void testSolution(int[] input, int[] expected) {
        int[] actual = solution.solution(input);
        // Check that the length of the arrays is the same
        assertEquals(expected.length, actual.length, "Length of the result array is incorrect");


        // Check that no heights are greater than the limits provided by array A
        for (int i = 0; i < input.length; i++) {
            assertTrue(actual[i] <= input[i], "Height exceeds the limit in A for index " + i);
        }

        // Check that all the values in array B are unique
        assertTrue(areValuesUnique(actual), "The values in the result array are not unique");

        // Optionally, verify the sum of the values in actual is as large as expected or valid
        assertTrue(isValidSum(actual, input), "The sum of heights is not optimal");
        Arrays.sort(expected);
        Arrays.sort(actual);
        assertTrue(Arrays.equals(expected, actual));

    }

    static Stream<Arguments> provideTestCases() {
        return Stream.of(
                // Example 1
                Arguments.of(new int[] {1, 2, 3}, new int[] {1, 2, 3}),

                // Example 2
                Arguments.of(new int[] {9, 4, 3, 7, 7}, new int[] {3, 4, 6, 7, 9}),

                // Example 3
                Arguments.of(new int[] {2, 5, 4, 5, 5}, new int[] {1, 2, 3, 4, 5}),

                // Edge Case 1
                Arguments.of(new int[] {1000000000, 999999999, 1000000000, 999999999},
                        new int[] {999999998, 999999997, 1000000000, 999999999}),

                // Edge Case 2
                Arguments.of(new int[] {1}, new int[] {1}),

                // Large Test Case
                Arguments.of(createLargeTestCase(), createExpectedLargeTestCase())
        );
    }

    // Helper function to check if the values in an array are unique
    private boolean areValuesUnique(int[] arr) {
        return Arrays.stream(arr).distinct().count() == arr.length;
    }

    // Helper function to check if the sum is valid, but doesn't have to be optimal (flexible validation)
    private boolean isValidSum(int[] result, int[] input) {
        long sumResult = Arrays.stream(result).mapToLong(Long::valueOf).sum();
        long sumInput = Arrays.stream(input).mapToLong(Long::valueOf).sum();
        return sumResult <= sumInput && sumResult > 0;
    }

    // Large test case generation
    private static int[] createLargeTestCase() {
        int N = 50000;
        int[] largeCase = new int[N];
        for (int i = 0; i < N; i++) {
            largeCase[i] = i + 1;
        }
        return largeCase;
    }

    // Large test case expected results
    private static int[] createExpectedLargeTestCase() {
        int N = 50000;
        int[] expectedCase = new int[N];
        for (int i = 0; i < N; i++) {
            expectedCase[i] = i + 1;
        }
        return expectedCase;
    }
}

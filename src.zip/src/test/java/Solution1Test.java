import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class Solution1Test {
    Solution1 sol = new Solution1();
    @Test
    void testSampeCase_0() {
        assertEquals(1, sol.solution("aaAabCCABBc"));
    }

    @Test
    void testSampeCase_1() {
        assertEquals(2, sol.solution("aaAbCCABBc"));
    }

    @Test
    void testSampeCase_2() {
        assertEquals(6, sol.solution("xyzXYZabcABC"));
    }

    @Test
    void testSampeCase_3() {
        assertEquals(0, sol.solution("ABCabcAefG"));
    }

    @Test
    void testBasicCase() {
        assertEquals(1, sol.solution("aA"));
    }

    @Test
    void testNoMatchCase() {
        assertEquals(3, sol.solution("abcABC"));
    }

    @Test
    void testAllLowerCase() {
        assertEquals(0, sol.solution("abcdef"));
    }

    @Test
    void testAllUpperCase() {
        assertEquals(0, sol.solution("ABCDEF"));
    }

    @Test
    void testMixedCase() {
        assertEquals(3, sol.solution("aAbBcC"));
    }

    @Test
    void testEmptyString() {
        assertEquals(0, sol.solution(""));
    }
}


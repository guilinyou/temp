class Solution11 {

    public int solution(String letters) {
        boolean[] lower_seen = new boolean[26];
        boolean[] upper_seen = new boolean[26];
        boolean[] invalid = new boolean[26];

        processLetters(letters, lower_seen, upper_seen, invalid);
        return countValidLetters(lower_seen, upper_seen, invalid);
    }

    // This method processes the string and updates the lower_seen, upper_seen, and invalid arrays
    private void processLetters(String letters, boolean[] lower_seen, boolean[] upper_seen, boolean[] invalid) {
        for (char ch : letters.toCharArray()) {
            if (Character.isLowerCase(ch)) {
                markLowerSeen(ch, lower_seen);
            } else {
                markUpperAndInvalidate(ch, lower_seen, upper_seen, invalid);
            }
        }
    }

    // This method marks a lowercase letter as seen
    private void markLowerSeen(char ch, boolean[] lower_seen) {
        lower_seen[ch - 'a'] = true;
    }

    // This method handles the uppercase letter logic and marks the letter as invalid if needed
    private void markUpperAndInvalidate(char ch, boolean[] lower_seen, boolean[] upper_seen, boolean[] invalid) {
        int index = Character.toLowerCase(ch) - 'a';
        if (!lower_seen[index]) {
            invalid[index] = true;  // Mark the letter as invalid if lowercase hasn't been seen
        } else {
            upper_seen[index] = true;  // Mark uppercase as seen
        }
    }

    // This method counts how many letters are valid according to the problem's condition
    private int countValidLetters(boolean[] lower_seen, boolean[] upper_seen, boolean[] invalid) {
        int valid_count = 0;
        for (int i = 0; i < 26; i++) {
            if (lower_seen[i] && upper_seen[i] && !invalid[i]) {
                valid_count++;
            }
        }
        return valid_count;
    }
}

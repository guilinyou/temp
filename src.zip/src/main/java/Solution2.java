import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

class Solution2 {
    public int[] solution(int[] A) {
        int N = A.length;
        int[] result = new int[N];
        int[] sortedA = A.clone();

        // Sort the array in descending order
        Arrays.sort(sortedA);

        // This will keep track of already assigned heights
        Set<Integer> assignedHeights = new HashSet<>();
        int currentMaxHeight = Integer.MAX_VALUE;

        // Assign heights starting from the largest possible height
        for (int i = N - 1; i >= 0; i--) {
            // Find the maximum height for the current skyscraper
            int maxPossibleHeight = sortedA[i];

            // Decrement currentMaxHeight until we find an available height
            while (currentMaxHeight > maxPossibleHeight || assignedHeights.contains(currentMaxHeight)) {
                currentMaxHeight--;
            }

            // Assign this height to the result array
            result[i] = currentMaxHeight;
            // Mark this height as used
            assignedHeights.add(currentMaxHeight);
        }

        // Now we need to place results back in original order
        int[] finalResult = new int[N];
        for (int i = 0; i < N; i++) {
            finalResult[i] = result[Arrays.binarySearch(sortedA, A[i])];
            // Adjust to ensure unique heights if necessary
            while (Arrays.binarySearch(finalResult, finalResult[i]) < 0) {
                finalResult[i]--;
            }
        }

        return finalResult;
    }
}

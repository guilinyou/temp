package org.example;

public class Main {
    private static final int intValue = 10;

    public void test() {
        int a = 1;
        int b = 2;
        int c = a + b;
    }

    public static void main(String[] args) {
        System.out.println("HelloWorld");
    }
}
class Solution111 {

    public int solution(String letters) {
        boolean[] lower_seen = new boolean[26];  // Tracks if lowercase letter (a-z) is seen
        boolean[] invalid = new boolean[26];     // Tracks if a letter is invalid due to uppercase appearing too early
        boolean[] upper_seen = new boolean[26];  // Tracks if uppercase has been seen at all

        processLetters(letters, lower_seen, upper_seen, invalid);
        return countValidLetters(lower_seen, upper_seen, invalid);
    }

    // This method processes the string and updates the lower_seen, upper_seen, and invalid arrays
    private void processLetters(String letters, boolean[] lower_seen, boolean[] upper_seen, boolean[] invalid) {
        for (char ch : letters.toCharArray()) {
            if (Character.isLowerCase(ch)) {
                handleLowerCase(ch, lower_seen, invalid, upper_seen);
            } else {
                handleUpperCase(ch, lower_seen, upper_seen, invalid);
            }
        }
    }

    // This method handles the lowercase letters logic
    private void handleLowerCase(char ch, boolean[] lower_seen, boolean[] invalid, boolean[] upper_seen) {
        int index = ch - 'a';
        if (!upper_seen[index]) {
            // Mark lowercase letter as seen only if no uppercase has been seen for this letter
            lower_seen[index] = true;
        }
    }

    // This method handles the uppercase letters logic
    private void handleUpperCase(char ch, boolean[] lower_seen, boolean[] upper_seen, boolean[] invalid) {
        int index = Character.toLowerCase(ch) - 'a';
        upper_seen[index] = true;  // Mark uppercase as seen

        // If lowercase hasn't been seen before this uppercase, mark it as invalid
        if (!lower_seen[index]) {
            invalid[index] = true;
        }
    }

    // This method counts how many valid letters where lowercase appeared before uppercase and no invalid flag
    private int countValidLetters(boolean[] lower_seen, boolean[] upper_seen, boolean[] invalid) {
        int valid_count = 0;
        for (int i = 0; i < 26; i++) {
            // The letter is valid if lowercase was seen, uppercase was seen, and it wasn't marked invalid
            if (lower_seen[i] && upper_seen[i] && !invalid[i]) {
                valid_count++;
            }
        }
        return valid_count;
    }
}

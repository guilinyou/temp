class Solution1 {

    public int solution(String letters) {
        boolean[] lowerSeen = new boolean[26];  // Track if lowercase letters (a-z) are seen
        boolean[] upperSeen = new boolean[26];  // Track if uppercase letters (A-Z) are seen
        boolean[] isInvalid = new boolean[26];  // Track if a letter is invalid (uppercase seen before lowercase or lowercase appears after uppercase)

        for (char ch : letters.toCharArray()) {
            if (Character.isLowerCase(ch)) {
                handleLowerCase(ch, lowerSeen, upperSeen, isInvalid);
            } else {
                handleUpperCase(ch, lowerSeen, upperSeen, isInvalid);
            }
        }

        return countValidLetters(lowerSeen, upperSeen, isInvalid);
    }

    // This method handles the lowercase letters logic
    private void handleLowerCase(char ch, boolean[] lowerSeen, boolean[] upperSeen, boolean[] isInvalid) {
        int index = ch - 'a';
        if (upperSeen[index]) {
            // If an uppercase has already been seen, any lowercase after it invalidates the letter
            isInvalid[index] = true;
        }
        // Mark the lowercase letter as seen
        lowerSeen[index] = true;
    }

    // This method handles the uppercase letters logic
    private void handleUpperCase(char ch, boolean[] lowerSeen, boolean[] upperSeen, boolean[] isInvalid) {
        int index = Character.toLowerCase(ch) - 'a';
        if (!lowerSeen[index]) {
            // If lowercase hasn't been seen before the uppercase, invalidate the letter
            isInvalid[index] = true;
        }
        // Mark the uppercase letter as seen
        upperSeen[index] = true;
    }

    // This method counts valid letters where lowercase appeared before uppercase and no invalid flag
    private int countValidLetters(boolean[] lowerSeen, boolean[] upperSeen, boolean[] isInvalid) {
        int validCount = 0;
        for (int i = 0; i < 26; i++) {
            // The letter is valid if lowercase was seen, uppercase was seen, and it wasn't marked as invalid
            if (lowerSeen[i] && upperSeen[i] && !isInvalid[i]) {
                validCount++;
            }
        }
        return validCount;
    }
}

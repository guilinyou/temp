import java.util.*;

class Solution3 {
    private List<Integer>[] graph;
    private int[] match;
    private boolean[] visited;

    public boolean solution(int[] A, int[] B, int S) {
        int N = A.length;
        
        // Initialize the graph
        graph = new List[N];
        for (int i = 0; i < N; i++) {
            graph[i] = new ArrayList<>();
            graph[i].add(A[i] - 1);
            graph[i].add(B[i] - 1);
        }
        
        // Initialize matching and visited arrays
        match = new int[S];
        Arrays.fill(match, -1);
        visited = new boolean[S];
        
        // Try to find a matching for each patient
        int matchCount = 0;
        for (int i = 0; i < N; i++) {
            Arrays.fill(visited, false);
            if (dfs(i)) {
                matchCount++;
            }
        }
        
        // If all patients are matched, return true
        return matchCount == N;
    }
    
    private boolean dfs(int patient) {
        for (int slot : graph[patient]) {
            if (!visited[slot]) {
                visited[slot] = true;
                if (match[slot] == -1 || dfs(match[slot])) {
                    match[slot] = patient;
                    return true;
                }
            }
        }
        return false;
    }
}

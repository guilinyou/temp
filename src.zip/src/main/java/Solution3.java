import java.util.*;

class Solution3 {
    // To keep track of the patient assigned to each slot
    private int[] slotMatched;
    // To keep track of visited slots during DFS
    private boolean[] visited;
    // The adjacency list to represent preferences (edges) for each slot
    private List<List<Integer>> graph;

    public boolean solution(int[] A, int[] B, int S) {
        int N = A.length;

        // Initialize adjacency list for slots (1 to S)
        graph = new ArrayList<>();
        for (int i = 0; i <= S; i++) {
            graph.add(new ArrayList<>());
        }

        // Fill the graph based on patients' preferences
        for (int i = 0; i < N; i++) {
            graph.get(A[i]).add(i); // Patient i prefers slot A[i]
            graph.get(B[i]).add(i); // Patient i prefers slot B[i]
        }

        // Initialize the slot to patient matching array
        slotMatched = new int[N];
        Arrays.fill(slotMatched, -1); // Initially, no patient is assigned to any slot

        // Try to find matching for each slot
        for (int slot = 1; slot <= S; slot++) {
            visited = new boolean[S + 1]; // reset visited array for each DFS
            if (!dfs(slot)) {
                return false; // If not all patients can be matched, return false
            }
        }

        // If all patients are matched successfully
        return true;
    }

    // DFS function to try assigning a patient to a slot
    private boolean dfs(int slot) {
        if (visited[slot]) {
            return false; // If this slot is already visited in this DFS, return false
        }
        visited[slot] = true;

        // Try to assign this slot to any patient that prefers it
        for (int patient : graph.get(slot)) {
            // If the patient is not assigned yet, or if we can reassign them to another slot
            if (slotMatched[patient] == -1 || dfs(slotMatched[patient])) {
                slotMatched[patient] = slot; // Assign this slot to the current patient
                return true;
            }
        }
        return false; // No valid assignment found
    }
}

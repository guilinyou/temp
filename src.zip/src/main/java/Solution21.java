import java.util.Arrays;
import java.util.stream.Collectors;

class Solution21 {
    public int[] solution(int[] A) {
        int N = A.length;

        // Step 1: Sort the array A and keep track of original indices
        int[][] indexedA = new int[N][2];
        for (int i = 0; i < N; i++) {
            indexedA[i][0] = A[i]; // height
            indexedA[i][1] = i;    // original index
        }

        // Sort by the height values
        Arrays.sort(indexedA, (a, b) -> b[0] - a[0] == 0 ? b[1] - a[1] : b[0] - a[0]);

        // Step 2: Assign the highest possible unique heights
        for (int i = 1; i < N; i++) {
            int pre = indexedA[i - 1][0];
            int curr = indexedA[i][0];
            indexedA[i][0] = getNextValid(pre, curr);
        }
        Arrays.sort(indexedA, (a, b) -> a[1] - b[1]);
        int[] result = Arrays.stream(indexedA).mapToInt(a -> a[0]).toArray();
        System.out.println(Arrays.stream(A).sequential().mapToObj(String::valueOf).collect(Collectors.joining(", ")) +" = "+ Arrays.stream(result).sequential().mapToObj(String::valueOf).collect(Collectors.joining(", ")));
        return result;
    }

    int getNextValid(int pre, int curr) {
        while (curr >= pre) {
            curr--;
        }
        return curr;
    }
}


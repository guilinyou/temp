public class Solution10 {

    public int solution(String letters) {
        int[] cache = new int[26];
        for (char c : letters.toCharArray()) {
            if (c >= 97) {
                int index = c - 97;
                if (cache[index] == 1) {
                    cache[index] = -2;
                } else {
                    cache[index] = -1;
                }
            } else {
                int index = c - 65;
                if (cache[index] == -1 || cache[index] == 1) {
                    cache[index] = 1;
                } else {
                    cache[index] = -2;
                }
            }
        }

        int result = 0;
        for (int i : cache) {
            result += i == 1 ? 1 : 0;
        }
        return result;
    }
}
